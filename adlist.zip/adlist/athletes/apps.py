from django.apps import AppConfig


class AthletesConfig(AppConfig):
    name = 'athletes'
