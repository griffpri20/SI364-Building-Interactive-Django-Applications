from django.apps import AppConfig


class CookiesConfig(AppConfig):
    name = 'cookies'
